"""Error envelope DTOs and health/version DTOs (docs/08 §4.2).

These are the frozen wire shapes for LG-002's real ``/health`` and ``/version``
endpoints plus the shared error envelope used by all API tasks.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .enums import ErrorCode


class ErrorBody(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: ErrorCode
    message: str
    details: dict[str, Any] = Field(default_factory=dict)
    retryable: bool = False
    request_id: str | None = None


class ErrorEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid")

    error: ErrorBody


class HealthResponse(BaseModel):
    """Process liveness, version and capability overview (docs/08 §4.3).

    ``capabilities`` reports only what is *actually* wired at skeleton stage.
    Unimplemented features stay ``False`` rather than being advertised.
    """

    model_config = ConfigDict(extra="forbid")

    status: str = "ok"
    package_version: str
    contract_version: str
    schema_version: str
    capabilities: dict[str, bool] = Field(default_factory=dict)


class VersionResponse(BaseModel):
    """Contract/schema/build information (docs/08 §4.3)."""

    model_config = ConfigDict(extra="forbid")

    contract_version: str
    schema_version: str
    package_version: str
    python_version: str
    platform: str


__all__ = ["ErrorBody", "ErrorEnvelope", "HealthResponse", "VersionResponse"]
